package com.enigma.wms.warungMakanSamudra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarungMakanSamudraApplicationTests {

	@Test
	void contextLoads() {
	}

}
